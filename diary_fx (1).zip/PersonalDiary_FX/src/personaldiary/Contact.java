
package personaldiary;

import java.util.GregorianCalendar;

/**
 * Class to manage the the contacts of the user, the class inherits from Person class.
 * @author Cesar
 */

public class Contact extends Person{
    /**
	 * 
	 */
	private static final long serialVersionUID = -6421498471157251506L;
	long contact_id; //used to identify the contact. Created using the time when the contact is created.
    String relationship = "friend", about = "";  
    //about is user to store the details about the contact user want's to remember.
    
    /**
     * Constructor for the class Person which takes the name of the user.
     * @param firstName
     * @param lastName 
     */
    public Contact(String firstName, String lastName){
        super(firstName, lastName);
        contact_id = new GregorianCalendar().getTimeInMillis();
    }
    
    /**
     * Getter method for relationship (of the contact with the user).
     * @return 
     */
    
   
    public String getRelationship(){
        return this.relationship;
    }
    
    /**
     * Getter method of the contact's about.
     * @return 
     */
    public String getAbout(){
        return this.about;
    }
    
    /**
     * Setter method for the contact's relationship with the user.
     * @param relationship 
     */
    public void setRelationship(String relationship){
        this.relationship = relationship;
    }
    /**
     * Setter method for the contact's about.
     * @param about 
     */
    public void setAbout(String about){
        this.about = about;
    }
    
    public String toString(){
        String res = "Name:" + firstName + " " + lastName;
        res += "\nEmail: " + emailAddress;
        res += "\nPhone Num:" + phoneNumber;
        return res;
    }
   
}

