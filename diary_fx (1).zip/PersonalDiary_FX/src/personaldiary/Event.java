
package personaldiary;

import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;

/**
 * Class to store information related to an Event.
 * @author hit
 */
public class Event extends Note {
    
 
	/**
	 * 
	 */
	private static final long serialVersionUID = -4062695935948555625L;
	String location;
    GregorianCalendar occurrenceDate;
    
    /**
     * Constructor of the class Event.
     * @param eventNote
     * @param location 
     */
    public Event(String eventNote, String location) {
        super(eventNote);
        this.location = location;
        this.occurrenceDate = PersonalDiary.NullDate;
        this.noteCategory = "Event";
    }
    
    /**
     * Getter method for the occurrenceDate.
     * @return GregorianCalendar : occurrenceDate
     */
    public GregorianCalendar getOccurenceDate(){
        return this.occurrenceDate;
    }
    
    /**
     * Getter method for the Location.
     * @return String : location
     */
    public String getLocation(){
        return this.location;
    }
    
    /**
     * Setter method for occurrence date.
     * @param day
     * @param month
     * @param year 
     */
    public void setOccurrenceDate(int day, int month, int year){
        this.occurrenceDate = new GregorianCalendar(year, month, day);
    }
    
    /**
     * Setter method for the location.
     * @param location 
     */
    public void setLocation(String location){
        this.location = location;
    }
    
     public String toString(){
        SimpleDateFormat dateFormatter = new SimpleDateFormat("E, d-M-y 'at' h:m:s a");
        String res = "Note: " + note + "\n" + "\nLocation: " + location +"\nOccurrence Date: " + dateFormatter.format(occurrenceDate.getTime());
                
        return res;
    }
    
}
