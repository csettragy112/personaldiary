
package personaldiary;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;



/**
 * The Handler of the application.
 * @author hit
 */

/**The Handler of the application.
 * The format of the objects in the text file "database" is :.
 * 1. User (mainUser).
 * 2. ContactsArray
 * 3. RemindersArray
 * 4. EventsArray
 * 
 */
public class Handler {
    
    ObjectOutputStream oos = null;
    FileOutputStream fout = null;
    String dbFileName;
    public User mainUser;
    public int dbfound = 0; //this variables tell us if we found old database or not.
    public ArrayList<Contact> contactsArray;
    public ArrayList<Reminder> remindersArray;
    public ArrayList<Event> eventsArray;
    public ArrayList<Note> notesArray;
    
    /**
     * Constructor for Handler.
     * @param dbfilename 
     */
    public Handler(String dbfilename){
        this.dbFileName = dbfilename;
        initializeApplication();
        
    }
    
    /**
     * To initialize the handler.
     */
    public void initializeApplication() {
        
        try {
            FileInputStream fin = new FileInputStream(dbFileName);
            updateFromDatabase();
            fin.close();
            
        } catch (Exception e){
            dbfound = 0;
            setDefault();
            }
    }
    
    /**
     * Sets all the values to default empty values.
     */
    public void setDefault(){
            mainUser = new User("", "", ""); //Empty User
            contactsArray = new ArrayList<Contact>();
            remindersArray = new ArrayList<Reminder>();
            eventsArray = new ArrayList<Event>();
            notesArray = new ArrayList<Note>();
    }
    
    /**
     * Creates a contact and return an Contact object.
     * @param firstName
     * @param lastName
     * @param phoneNumber
     * @param relationship
     * @param birthday_day
     * @param birthday_month
     * @param birthday_year
     * @param about
     * @param emailAddress
     * @return 
     */
    public Contact createContact(String firstName, String lastName, String phoneNumber, String relationship, int birthday_day, int birthday_month, int birthday_year, String about, String emailAddress){
        Contact contact = new Contact(firstName, lastName);
        contact.setPhoneNumber(phoneNumber);
        contact.setBirthDay(birthday_day, birthday_month, birthday_year);
        contact.setEmailAddress(emailAddress);
        contact.setAbout(about);
        contact.setRelationship(relationship);
        return contact;
    }
    
    /**
     * Adds the contact to contactArray by ordering on the basis of first name.
     * @param contact 
     */
    public void addContact(Contact contact){
        String name = contact.getFirstName();
        int index = 0;
        while (index < contactsArray.size()){
            if (contactsArray.get(index).getFirstName().compareToIgnoreCase(name)<= -1){
                index++;
            }
            else{
                break;
            }
        }
        //now we can put the contact
        contactsArray.add(index, contact); 
    }
    
    /**
     * Updates/Replace the old_contact with new one.
     * @param old_contact
     * @param new_contact 
     */
    public void updateContact(Contact old_contact, Contact new_contact){
        int index = contactsArray.indexOf(old_contact);
        if (index != -1){
            contactsArray.remove(index);
            addContact(new_contact);
        }
    }
    
    /**
     * Deletes the input contact.
     * @param contact
     * @return 
     */
    public boolean deleteContact(Contact contact){
        int index = contactsArray.indexOf(contact);
        if (index != -1){
            contactsArray.remove(index);
            return true;
        } else {
            return false;
        }
    }
    
    /**
     * Creates a reminder and return a Reminder object.
     * @param note
     * @param day - reminder day
     * @param month - reminder month
     * @param year - reminder year
     */
    public Reminder createReminder(String note, int day, int month, int year ){
        Reminder reminder = new Reminder(note, day, month, year);
        return reminder;
    }
    
    /**
     * Adds the reminder object to reminders array by maintaining the order.
     * @param reminder 
     */
    public void addReminder(Reminder reminder){
        //reminders will be added on the bases of reminderDate.
        int index = 0;
        while (index < remindersArray.size()){
            if (remindersArray.get(index).getReminderDate().before(reminder.reminderDate)){
                index++;
            }
            else{
                break;
            }
        }
        remindersArray.add(index, reminder);
    }
    
    /**
     * Updates the old_reminder with new_reminder.
     * @param old_reminder
     * @param new_reminder 
     */
    public void updateReminder(Reminder old_reminder, Reminder new_reminder){
        int index = remindersArray.indexOf(old_reminder);
        if (index != -1){
            remindersArray.remove(index);
             addReminder( new_reminder);
        }
    }
    
    /**
     * Deletes the given reminder.
     * @param reminder
     * @return 
     */
    public boolean deleteReminder(Reminder reminder){
        int index = remindersArray.indexOf(reminder);
        if (index != -1){
            remindersArray.remove(index);
            return true;
        }
        else{
            return false;
        }
    }
    
    /**
     * Creates and returns an Event object.
     * @param eventNote
     * @param location
     * @param day
     * @param month
     * @param year
     * @return 
     */
    public Event createEvent(String eventNote, String location, int day, int month, int year){
        Event event = new Event(eventNote, location);
        event.setOccurrenceDate(day, month, year);
        return event;
    }
    
    public Note createNote(String noteString){
        Note note = new Note(noteString);
        return note;
    }
    
    public void addNote(Note note){
        int index = 0;
        while (index < notesArray.size()){
            if (notesArray.get(index).getDateCreated().before(note.getDateCreated())){
                index++;
            }
            else{
                break;
            }
        }
        notesArray.add(index,note);
    }
    
    public void deleteNote(Note note){
        notesArray.remove(note);
    }
    
    
    /**
     * Adds a event object to the events array.
     * @param event 
     */
    public void addEvent(Event event){
        //Event will be added on the bases of occurrence date.
        int index = 0;
        while (index < eventsArray.size()){
            if (eventsArray.get(index).getOccurenceDate().before(event.occurrenceDate)){
                index++;
            }
            else{
                break;
            }
        }
        eventsArray.add(index, event);
    }
    
    /**
     * Updates the old event with new one by deleting it and adding new one.
     * @param old_event
     * @param new_event 
     */
    public void updateEvent(Event old_event, Event new_event) {
        int index = eventsArray.indexOf(old_event);
        if (index != -1){
            eventsArray.remove(index);
            addEvent(new_event);
        }
    }
    
    /**
     * Deletes the given event.
     * @param event
     * @return 
     */
    public boolean deleteEvent(Event event) {
        int index = eventsArray.indexOf(event);
        if (index != -1){
            eventsArray.remove(index);
            return true;
        }
        else return false;
    }
    
    /**
     * Returns the event with given id if found, else null.
     * @param id
     * @return 
     */
    public Event searchEvent(long id){
        for (Event event: eventsArray){
           if (event.note_id == id ){
               return event;
           }
        }
        return null;
    }
    
    /**
     * Return the reminder with given id if found else null.
     * @param id
     * @return 
     */
    public Reminder searchReminder(long id){
        for (Reminder reminder: remindersArray){
           if (reminder.note_id == id ){
               return reminder;
           }
        }
        return null;
    }
    
    /**
     * Returns the contact with given id if found else null.
     * @param id
     * @return Contact
     */
    public Contact searchContact(long id){
        for (Contact contact: contactsArray){
           if (contact.contact_id == id ){
               return contact;
           }
        }
        return null;
    }
    
    /**
     * Gets the data from the database and replaces the data of the application.
     * @throws IOException 
     */
    @SuppressWarnings("unchecked")
	public void updateFromDatabase() throws IOException{
        FileInputStream fin = new FileInputStream(new File(dbFileName));
        ObjectInputStream ois = null;
        try{
            ois = new ObjectInputStream(fin);
            mainUser = (User) ois.readObject();
            contactsArray = (ArrayList<Contact>) ois.readObject();
            remindersArray = (ArrayList<Reminder>) ois.readObject();
            eventsArray = (ArrayList<Event>) ois.readObject();
            notesArray = (ArrayList<Note>) ois.readObject();
            
            dbfound = 1; //We found database.
            
        } catch (Exception e){
            e.printStackTrace();
        }
        finally {
           if(ois != null){
               ois.close();
           }
    } 

    }
    
    /**
     * Updates the database by the information currently stored in the application.
     * @throws IOException 
     */
    public void updateDatabase() throws IOException{
        FileOutputStream fos = null;
        ObjectOutputStream oos = null;
         try {
            File f = new File (dbFileName);
            if (f.exists()) f.delete();
            
            f.createNewFile();
            
            fos = new FileOutputStream(f);
            oos =  new ObjectOutputStream(fos);
            oos.writeObject(mainUser);
            oos.writeObject(contactsArray);
            oos.writeObject(remindersArray);
            oos.writeObject(eventsArray);
            oos.writeObject(notesArray);
            
         } catch (Exception e){
             e.printStackTrace();
         } finally{
             if (fos != null) fos.close();
             if (oos != null) oos.close();
         }
    }
    
    /**
     * Updates the user information.
     * @param newUser 
     */
    public void updateUserInformation(User newUser){
        mainUser = newUser;
    }
    
    public String getHTMLExport(){  
        String head = "<head>\n" +
            "<style>\n" +
            "table {\n" +
            "  font-family: arial, sans-serif;\n" +
            "  border-collapse: collapse;\n" +
            "  width: 100%;\n" +
            "}\n" +
            "\n" +
            "td, th {\n" +
            "  border: 1px solid #dddddd;\n" +
            "  text-align: left;\n" +
            "  padding: 8px;\n" +
            "}\n" +
            "\n" +
            "tr:nth-child(even) {\n" +
            "  background-color: #dddddd;\n" +
            "}\n" +
            "h2"+
            "{ text-align:center; }\n"+
            "</style>\n" +
            "</head>";
        
        String html = "<html>"+ head +"<body>\n";
        //add User
        html += "<div>\n";
        html += "<h1>User Name: " + mainUser.firstName + " " + mainUser.lastName + "</h1></div><br><hr><br>\n";
        //add contacts
        html += "<hr><br><div><h2>Contacts<h2><br>\n";
        html += "<table><thead><tr><td>Contact Name</td><td>Phone Number</td><td>Email Address</td><td>Relationship</td></tr></thead><tbody>\n";
        for (Contact c: contactsArray){
            html += String.format("<tr><td>%s %s</td><td>%s</td><td>%s</td><td>%s</td></tr>\n", c.getFirstName(), c.getLastName(), c.getPhoneNumber(), c.getEmailAddress(), c.getRelationship());
        }
        html += "</tbody></table>\n</div>\n";
        
        //add Notes
        html += "<hr><br><div><h2>Notes</h2><br>\n";
        html += "<table><thead><tr><td>Note</td><td>Date Created</td></tr></thead><tbody>\n";
        for (Note n: notesArray){
            html += String.format("<tr><td>%s</td><td>%tc</td></tr>\n", n.getNote(), n.getDateCreated());
        }
        html += "</tbody></table>\n</div>";
        
        //add Events
        html += "<hr><br><div><h2>Events</h2><br>\n";
        html += "<table><thead><tr><td>Note</td><td>Event Date</td><td>Location</td><td>Date Created</td></tr></thead><tbody>\n";
        for (Event e: eventsArray){
            html += String.format("<tr><td>%s</td><td>%tc</td><td>%s</td><td>%tc</td></tr>\n", e.getNote(), e.getOccurenceDate(), e.getLocation(),e.getDateCreated());
        }
        html += "</tbody></table>\n</div>\n";
        
        
        html += "<hr></body>\n</html>\n";
        
            
        //add Reminders
        html += "<hr><br><div><h2>Reminders</h2><br>";
        html += "<table><thead><tr><td>Note</td><td>Reminder Date</td><td>Date Created</td></tr></thead><tbody>";
        for (Reminder r: remindersArray){
            html += String.format("<tr><td>%s</td><td>%tc</td><td>%tc</td></tr>", r.getNote(), r.getReminderDate(), r.getDateCreated());
        }
        html += "</tbody></table></div>";
        
        
        html += "<hr></body></html>";
        
        
        return html;
    }
    
    public void exportHTMLToFile(File file) {
        String content = getHTMLExport();
        try {
            PrintWriter writer;
            writer = new PrintWriter(file);
            writer.println(content);
            writer.close();
        } catch (IOException ex) {
            System.out.println("Export Failed!");
        }
    }
 
}
