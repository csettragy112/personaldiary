
package personaldiary;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;

/**
 * Class to store the data related to a note created by the user.
 * @author Cesar
 */

@SuppressWarnings("serial")
public class Note  implements Serializable {
	
	String note, noteCategory;
    long note_id;
    GregorianCalendar date_created;
    //dateByUser is the date choosen by the user for the notes date.
    //date_created is the actual time when the note was first created.
    
    /**
     * Constructor for the Note class objects.
     * @param note 
     */
    public Note(String note){
        this.note = note;
        this.date_created = new GregorianCalendar(); //this will store the date at which the note is created.
        this.note_id = date_created.getTimeInMillis(); //a note is uniquely identified by the exact time it was created.
    }
    
    /**
     * Getter method for the note of the Note object.
     * @return String: note
     */
    public String getNote(){
        return this.note;
    }
    
    /**
     * Getter method for the note category of the note.
     * @return String noteCategory
     */
    public String getNoteCategory(){
        return this.noteCategory;
    }
    
    /**
     * Getter method for the note_id of the note.
     * @return long : note_id
     */
    public long getNoteId(){
        return this.note_id;
    }
    
    
    /**
     * Getter method for the date_created of the note. 
     * @return GregorianCalendar: date_created
     */
    public GregorianCalendar getDateCreated(){
        return this.date_created;
    }
    
    /**
     * Setter method for the note of the Note object.
     * @param note 
     */
    public void setNote(String note){
        this.note = note;
    }
    
    /**
     * Setter method for the noteCategory of the note.
     * @param noteCategory 
     */
    public void setNoteCategory(String noteCategory){
        this.noteCategory = noteCategory;
    }
    
    public String getFormattedDate(GregorianCalendar date){
        SimpleDateFormat dateFormatter = new SimpleDateFormat("E, d-M-y 'at' h:m:s a");
        return  dateFormatter.format(date.getTime());
    }
    public String toString(){
        SimpleDateFormat dateFormatter = new SimpleDateFormat("E, d-M-y 'at' h:m:s a");
        String res = "Note: " + note + "\n" + "Date Created: " + dateFormatter.format(date_created.getTime());
        return res;
    }
    
}
