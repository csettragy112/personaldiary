
package personaldiary;

import java.io.Serializable;
import java.util.GregorianCalendar;

/**
 * Class to manage the Person.
 * @author Cesar
 */

public class Person implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String firstName, lastName, phoneNumber, bloodGroup, emailAddress;
    GregorianCalendar birthday, nextHealthCheckUp;
    
    /**
     * Constructor for the class Person which takes the name of the user.
     * @param firstName
     * @param lastName 
     */
    public Person(String firstName, String lastName){
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = this.bloodGroup = this.emailAddress = "";
        //Set the date to default value which represents invalid date.
        this.birthday = PersonalDiary.NullDate;
        this.nextHealthCheckUp = PersonalDiary.NullDate;
    }
    
    /**
     * Getter method for firstName.
     * @return String:firstName
     */
    public String getFirstName(){
        return this.firstName;
    }
    
    /**
     * Getter method for lastName.
     * @return String: lastName
     */
    public String getLastName(){
        return this.lastName;
    }
    
    /**
     * Getter method for the phone number of the Person.
     * @return String : phone number
     */
    public String getPhoneNumber(){
        return this.phoneNumber;
    }
    
    
    /**
     * Getter method for birthday.
     * @return GregorianCalendar: birthday
     */
    public GregorianCalendar getBirthday(){
        return this.birthday;
    }
    
    /**
     * Getter method for nextHealthCheckUp date.
     * @return GregorianCalendar: nextHealthCheckUp
     */
    public GregorianCalendar getNextHealthCheckUp(){
        return this.nextHealthCheckUp;
    }
    
    /**
     * Getter method for bloodGroup.
     * @return String: bloodGroup
     */
    public String getBloodGroup(){
        return this.bloodGroup;
    }
    
    /**
     * Getter method for emailAddress.
     * @return String: emailAddress
     */
    public String getEmailAddress(){
        return this.emailAddress;
    }
    
    /**
     * Setter method for firstName.
     * @param firstName 
     */
    public void setFirstName(String firstName){
        this.firstName = firstName;
    }
    
    /**
     * Setter method for lastName.
     * @param lastName 
     */
    public void setLastName(String lastName){
        this.lastName = lastName;
    }
    
    /**
     * Setter method for phone number.
     * @param phoneNumber 
     */
    public void setPhoneNumber(String phoneNumber){
        this.phoneNumber = phoneNumber;
    }
    /**
     * Setter method for birthday of the Person.
     * @param day
     * @param month
     * @param year 
     */
    public void setBirthDay(int day, int month, int year){
        this.birthday = new GregorianCalendar(year, month, day);
    }
    
    /**
     * Setter method for bloodGroup
     * @param bloodGroup 
     */
    public void setBloodGroup(String bloodGroup){
        this.bloodGroup = bloodGroup;
    }
    
    /**
     * Setter method for emailAddress.
     * @param emailAddress 
     */
    public void setEmailAddress(String emailAddress){
        this.emailAddress = emailAddress;
    }
    
    public String toString(){
        String res = "Name:" + firstName + " " + lastName;
        res += "\nEmail: " + emailAddress;
        return res;
    }
    

}

