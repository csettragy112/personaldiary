
package personaldiary;

import java.util.GregorianCalendar;

/**
 * The main GUI class of the application
 * @author Cesar
 */
public class PersonalDiary {
    public static GregorianCalendar NullDate = new GregorianCalendar(1,1,1);
   
    
    
}
