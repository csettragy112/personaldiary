
package personaldiary;

import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;

/**
 * Class Reminder is user to store information related to a Reminder created by the user, it extends Note class.
 * @author hit
 */

public class Reminder extends Note {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	GregorianCalendar reminderDate;
    
    /**
     * Constructor of the Reminder class.
     * @param note
     * @param day
     * @param month
     * @param year 
     */
    public Reminder(String note, int day, int month, int year) {
        super(note);
        this.reminderDate = new GregorianCalendar(year, month, day);
        this.noteCategory = "Reminder";
    }


    
    /**
     * Getter method for the reminder date for the Reminder.
     * @return 
     */
    public GregorianCalendar getReminderDate(){
        return this.reminderDate;
 
    }
    
    /**
     * Setter method for the reminder date.
     * @param reminderDate 
     */
    public void setReminderDate(GregorianCalendar reminderDate){
        this.reminderDate = reminderDate;
    }
    
    public String toString(){
        SimpleDateFormat dateFormatter = new SimpleDateFormat("E, d-M-y 'at' h:m:s a");
        String res = "Note: " + note + "\n" + "Reminder Date: " + dateFormatter.format(reminderDate.getTime());
        return res;
    }
    
}

