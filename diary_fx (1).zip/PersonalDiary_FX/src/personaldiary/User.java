
package personaldiary;

import java.io.Serializable;
import java.util.GregorianCalendar;

/**
 * Class to manage the main User of the Personal Diary Application,
 * It inherits from the class Person.
 * @author Cesar
 */

public class User extends Person implements Serializable{
    
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	GregorianCalendar nextHealthCheckUp;
    String password;
    
    /**
     * Constructor for the class Person which takes the name of the user.
     * @param firstName
     * @param lastName 
     */
    public User(String firstName, String lastName, String password){
        super(firstName, lastName);
        this.password = password;
    }
    
    /**
     * Getter for password.
     * @return 
     */
    public String getPassword(){
        return password;
    }
    
   
    /**
     * Getter method for nextHealthCheckUp date.
     * @return GregorianCalendar: nextHealthCheckUp
     */
    public GregorianCalendar getNextHealthCheckUp(){
        return this.nextHealthCheckUp;
    }
    
    /**
     * Setter method for nextHealthCheckUp.
     * @param day
     * @param month
     * @param year 
     */
    public void setNextHealthCheckUp(int day, int month, int year){
        this.nextHealthCheckUp = new GregorianCalendar(year, month, day);
    }

}

