/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package personaldiary.gui;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import personaldiary.Contact;

/**
 *
 * @author hit
 */
public class ContactCreateUpdatePanel {

    GridPane gridPaneConReg;
    TextField firstnameField_C;
    TextField lastnameField_C;
    TextField phoneNumberField_C;
    TextField aboutField_C;
    TextField relationshipField_C;
    TextField emailField_C;
    
    Scene createUpdateContact;
    Contact updateContact = null;


    
    ContactCreateUpdatePanel(final PersonalDiaryFX parent){
        /**
         * Now we will setup create contact form
         */
        gridPaneConReg = new GridPane();
        gridPaneConReg.getStyleClass().add("screen");
        gridPaneConReg.setStyle(parent.mainStyle);
        gridPaneConReg.setAlignment(Pos.CENTER);
        gridPaneConReg.setPadding(new Insets(40, 40, 40, 40));
        gridPaneConReg.setHgap(10);
        gridPaneConReg.setVgap(10);

        // Add the labels and the fields to the the gridPaneConReg we created.
        
        Label headerLabelConReg = new Label("Create/Update Contact");
        headerLabelConReg.setFont(Font.font("ArialBlack", 24));
        gridPaneConReg.add(headerLabelConReg, 0,0,1,1);
        GridPane.setHalignment(headerLabelConReg, HPos.CENTER);
        GridPane.setMargin(headerLabelConReg, new Insets(10, 0,10,0));
        
         // Add first First Name Label
        Label firstnameLabel_C = new Label("First Name : ");

        // Add Name Text Field
        firstnameField_C = new TextField();
        firstnameField_C.setPrefHeight(40);
        
        // Add last Name Label
        Label lastnameLabel_C = new Label("Last Name : ");

        // Add Name Text Field
        lastnameField_C = new TextField();
        lastnameField_C.setPrefHeight(40);
        
        // Add Email Label
        Label emailLabel_C = new Label("Email ID : ");   
        
         // Add Phone Number Label
        Label phoneNumberLabel_C = new Label("Phone Number : ");
        phoneNumberField_C = new TextField();
        phoneNumberField_C.setPrefHeight(40);

        // Add Email Text Field
        emailField_C = new TextField();
        emailField_C.setPrefHeight(40);
        
        gridPaneConReg.add(firstnameLabel_C, 0,1);
        firstnameField_C.setText("");
        gridPaneConReg.add(firstnameField_C, 1,1);

        // Add last Name Label
        gridPaneConReg.add(lastnameLabel_C, 0,2);
        
        lastnameField_C.setText("");
        gridPaneConReg.add(lastnameField_C, 1,2);
        
        // Add Email Label
        gridPaneConReg.add(emailLabel_C, 0, 3);
        emailField_C.setText("");
        gridPaneConReg.add(emailField_C, 1, 3);

        // Add Phone Number Label
        gridPaneConReg.add(phoneNumberLabel_C, 0, 4);
        phoneNumberField_C.setText("");
        gridPaneConReg.add(phoneNumberField_C, 1, 4);
        
        
        Label aboutLabel = new Label("About : ");
        gridPaneConReg.add(aboutLabel, 0, 5);
        aboutField_C = new TextField();
        gridPaneConReg.add(aboutField_C, 1, 5);
        
        Label relationshipLabel = new Label("Relationship : ");
        gridPaneConReg.add(relationshipLabel, 0, 6);
        relationshipField_C = new TextField();
        gridPaneConReg.add(relationshipField_C, 1, 6);

        // Add submitContactBtn Button
        Button submitContactBtn = new Button("Submit");
        submitContactBtn.setPrefHeight(40);
        submitContactBtn.setDefaultButton(true);
        submitContactBtn.setPrefWidth(100);
        gridPaneConReg.add(submitContactBtn, 0, 9, 2, 1);
        GridPane.setHalignment(submitContactBtn, HPos.CENTER);
        GridPane.setMargin(submitContactBtn, new Insets(20, 0,20,0));
        
        submitContactBtn.setOnAction(new EventHandler<ActionEvent>() {
         public void handle(ActionEvent event) {
                System.out.println("Contact Page opened.");
                String firstName = firstnameField_C.getText();
                String lastName = lastnameField_C.getText();
                String email = emailField_C.getText();
                String phoneNumber = phoneNumberField_C.getText();
                String relationship = relationshipField_C.getText();
                String about = aboutField_C.getText();
                Contact c = parent.handler.createContact(firstName, lastName, phoneNumber, relationship, 0, 0, 0, about, email);
                if (updateContact != null){
                    parent.handler.updateContact(updateContact, c);
                    updateContact = null;
                }
                else{
                    parent.handler.addContact(c);   
                }
                parent.message.setText("Contact Updated Successfully!");
                parent.primaryStage.setScene(parent.mainScene);
            }
        });
          
        Button goBackCC = parent.getBackButton();
        
        gridPaneConReg.add(goBackCC,0,10);
        createUpdateContact = new Scene(gridPaneConReg, PersonalDiaryFX.width, PersonalDiaryFX.height);
        
    }
    
    public Scene getScene(){
        return createUpdateContact;
    }
    
    public void updateFields(Contact c){
        firstnameField_C.setText(c.getFirstName());
        lastnameField_C.setText(c.getLastName());
        phoneNumberField_C.setText(c.getPhoneNumber());
        aboutField_C.setText(c.getAbout());
        relationshipField_C.setText(c.getRelationship());
        emailField_C.setText(c.getEmailAddress());
        
        updateContact = c;
        
    }
    
}
