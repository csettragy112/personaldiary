/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package personaldiary.gui;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;


/**
 *
 * @author hit
 */
public class EventPanel {

    private final Scene createEventScene;
    TextField locationField ;
    
    
    EventPanel(final PersonalDiaryFX parent){
          /**
         * Now we will setup the scene for creating Event
         */
        GridPane gridPaneCE = new GridPane();
        gridPaneCE.getStyleClass().add("screen");
        gridPaneCE.setAlignment(Pos.CENTER);
        gridPaneCE.setPadding(new Insets(40, 40, 40, 40));
        gridPaneCE.setHgap(10);
        gridPaneCE.setVgap(10);

        // Add the labels and the fields to the the gridPaneUR we created.
        Label headerLabelE = new Label("Add the following note as an Event:\n\n" + parent.note.getText());
        headerLabelE.setFont(Font.font("ArialBlack", 24));
        gridPaneCE.add(headerLabelE, 0,0,1,1);
        GridPane.setHalignment(headerLabelE, HPos.CENTER);
        GridPane.setMargin(headerLabelE, new Insets(10, 0,10,0));
        
        // Add first First Name Label
        Label locationLabel = new Label("Location: ");
        gridPaneCE.add(locationLabel, 0,1);
        
        // Add Name Text Field
        locationField = new TextField();
        locationField.setPrefHeight(40);
        gridPaneCE.add(locationField, 1,1);
        
        Label occurrenceDayLabel = new Label("Occurrence Date : ");
        gridPaneCE.add(occurrenceDayLabel, 0, 2);
        final DatePicker eventDateField = new DatePicker();
        gridPaneCE.add(eventDateField, 1, 2);
       
        
        // Add Submit Button for event
        Button submitEvent = new Button("Submit");
        submitEvent.setPrefHeight(40);
        submitEvent.setDefaultButton(true);
        submitEvent.setPrefWidth(100);
        gridPaneCE.add(submitEvent, 0,6, 2, 1);
        GridPane.setHalignment(submitEvent, HPos.CENTER);
        GridPane.setMargin(submitEvent, new Insets(20, 0,20,0));
        
        
        Button goBackCE = parent.getBackButton();
        
        gridPaneCE.add(goBackCE, 0, 7 ,2,1);
        submitEvent.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                int day = 0, month=0, year = 0;
                String location = locationField.getText();
                try{
                    
                day = eventDateField.getValue().getDayOfMonth();
                month = eventDateField.getValue().getMonthValue();
                year = eventDateField.getValue().getYear();
                
                } catch (Exception e){
                    //If date is invalid then
                    return;
                }
                parent.handler.addEvent(parent.handler.createEvent(parent.note.getText(), location, day, month, year));
                parent.note.setText("");
                parent.primaryStage.setScene(parent.mainScene);
            }
            });
            createEventScene = new Scene(gridPaneCE, PersonalDiaryFX.width, PersonalDiaryFX.height);
        
    }
    
    public Scene getScene(){
        return createEventScene;
    }
    
}
