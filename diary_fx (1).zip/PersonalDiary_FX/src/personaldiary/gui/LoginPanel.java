/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package personaldiary.gui;

import static javafx.application.Application.STYLESHEET_CASPIAN;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;


/**
 *
 * @author hit
 */
public class LoginPanel {

    private GridPane gridPaneLogin;
    private final Scene loginScene;
    LoginPanel(final PersonalDiaryFX parent) {
                
        gridPaneLogin = new GridPane();
        gridPaneLogin.getStyleClass().add("screen");
        gridPaneLogin.setStyle(parent.mainStyle);
        gridPaneLogin.setAlignment(Pos.CENTER);
        gridPaneLogin.setPadding(new Insets(40, 40, 40, 40));
        gridPaneLogin.setHgap(10);
        gridPaneLogin.setVgap(10);
        Label messagetop = new Label("Hi, " + parent.handler.mainUser.getFirstName() + " !\nWelcome Back!Please login.\n" );
        messagetop.setFont(Font.font(STYLESHEET_CASPIAN, FontWeight.BOLD, FontPosture.REGULAR, 15));
        
        gridPaneLogin.add(messagetop, 0, 1);
        final Label message = new Label("");
        message.setFont(Font.font(STYLESHEET_CASPIAN, FontWeight.BOLD, FontPosture.REGULAR, 15));
        
        gridPaneLogin.add(message, 0, 2);
        
        Label passwordLabel = new Label("Password : ");
        passwordLabel.setFont(parent.btnFont);
        gridPaneLogin.add(passwordLabel, 0, 3);
        final PasswordField passwordField = new PasswordField();
        passwordField.setPrefHeight(40);
        gridPaneLogin.add(passwordField, 1, 3);

        // Add Submit Button
        Button submitButton = new Button("Submit");
        submitButton.setPrefHeight(40);
        submitButton.setDefaultButton(true);
        submitButton.setPrefWidth(100);
        gridPaneLogin.add(submitButton, 0, 4 , 2, 1);
        GridPane.setHalignment(submitButton, HPos.CENTER);
        GridPane.setMargin(submitButton, new Insets(20, 0,20,0));
        submitButton.setOnAction(new EventHandler<ActionEvent>() {
         public void handle(ActionEvent event) {
                try {
                    String password = passwordField.getText();
                    if (parent.handler.mainUser.getPassword().equals(password)){
                        parent.userAuthentication = true;
                        parent.createScenes();
                        parent.primaryStage.setScene(parent.mainScene);
                    }
                    
                    else{
                        passwordField.setText("");
                        message.setText("Wrong Password!!");
                        
                    }
                } catch (Exception e) {
                    return;
                }
            }
        });   
       loginScene = new Scene(gridPaneLogin, PersonalDiaryFX.width, PersonalDiaryFX.height);
    }
    
    Scene getScene(){
        return loginScene;
    }
}
