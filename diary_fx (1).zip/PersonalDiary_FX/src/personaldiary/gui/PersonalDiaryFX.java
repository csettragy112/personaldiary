
package personaldiary.gui;

import java.io.File;
import java.io.IOException;
import java.util.Optional;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Screen;
import personaldiary.Contact;
import personaldiary.Event;
import personaldiary.Handler;
import personaldiary.Note;
import personaldiary.Reminder;

/**
 * PersonalDiaryFX is the GUI application which provides the user an interface to manage a Diary.
 * @author hit
 */
public class PersonalDiaryFX extends Application {
    
    /**
     * Start method for the application.
     * @param primaryStage 
     */
    
    
    Handler handler = new Handler("database.bin");
    VBox contactsBox = new VBox(20);
    VBox eventsBox = new VBox(20);
    VBox remindersBox = new VBox(20);
    VBox notesBox = new VBox(20);
    Scene welcome;
    Scene userRegistration;
    Scene loginScene;
    Scene mainScene;
    Scene data_view;
    Scene createEvent;
    Scene createReminder;
    Scene createUpdateContact;
    Scene updateUser;
    
    String mainStyle = "";
    String btnStyle = "";
    
    GridPane gridPaneConReg;
    
    Stage primaryStage;
    ScrollPane scroll_pane;
    static int width, height;
    static {
        width = (int)(Screen.getPrimary().getBounds().getWidth()*0.9);
        height =  (int)(Screen.getPrimary().getBounds().getHeight()*0.9);
       
    }
    double btnHeight = 60, btnWidth = 180;
    Font btnFont = Font.font(STYLESHEET_CASPIAN, FontWeight.SEMI_BOLD, FontPosture.REGULAR, 15);
    Button goBackCB=getBackButton(width, 40), goBackRB=getBackButton(width, 40), goBackEB=getBackButton(width, 40), 
            goBackNB = getBackButton(width, 40);
    
    boolean userAuthentication = false;
    TextField firstnameField_C;
    TextField lastnameField_C;
    ContactCreateUpdatePanel contactPanel;
    EventPanel createEventPanel;
    TextArea note;
    UserRegistrationPanel userRegistrationPanel;
    Text message;
    private Insets buttonInsets = new Insets(20,20,20,20);
    
    
    public void start(final Stage primaryStage) {
        this.primaryStage = primaryStage;
        FlowPane gp1 = new FlowPane();
        gp1.setOrientation(Orientation.VERTICAL);
        gp1.getStyleClass().add("screen");
        gp1.setAlignment(Pos.CENTER);
        gp1.setPadding(new Insets(40, 40, 40, 40));
        gp1.setHgap(10);
        gp1.setVgap(200);
        LoginPanel loginPanel = new LoginPanel(this);
        loginScene = loginPanel.getScene();
        loginScene.getStylesheets().add("mainStyle.css");
        
        Label text = new Label("Welcome to  Personal Diary Application");
        text.setFont(new Font(45));
        text.setAlignment(Pos.CENTER);
        text.setPrefWidth(width);
        //text.setY(height/2);
        //text.setX(width/2 - text.getBoundsInParent().getWidth()/2);

        Button btn = new Button();
        btn.setText("Proceed");
        btn.setId("proceed-button");
        btn.setPrefWidth(width);
        btn.setFont(Font.font(STYLESHEET_CASPIAN, FontPosture.REGULAR, 45));
        
        
        
        
        System.out.println(handler.mainUser);
        btn.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                if (handler.dbfound == 0){
                     primaryStage.setScene(userRegistration);
                }
                else{
                    primaryStage.setScene(loginScene);
                }
            }
        });
        gp1.getChildren().addAll(text, btn);
        gp1.setId("pane");
        welcome = new Scene(gp1, width,height);
        welcome.getStylesheets().add("mainStyle.css");
        
        
        userRegistrationPanel = new UserRegistrationPanel(this);
        
        userRegistration = userRegistrationPanel.getScene();
        userRegistration.getStylesheets().add("mainStyle.css");
        
        // Set the scene in primary stage	
        primaryStage.setScene(welcome);
        primaryStage.setTitle("Personal Diary");
        primaryStage.show();
        
  
  }
    void createScenes(){
        /**
         * Now we will setup the mainScene of the application
         */
        BorderPane bp = new BorderPane();
        bp.getStyleClass().add("screen");
        bp.setPadding(new Insets(10,10,10,10));
        Text text;
        text = new Text("Hi "+ handler.mainUser.getFirstName() + ", write what's on your mind today!\n");
        message = new Text("");
        text.setFont(new Font(20));
        message.setFont(new Font(20));
        text.setX(20);
        text.setY(10);
        bp.setTop(text);
        
        message.setX(20);
        bp.setBottom(message);
        note = new TextArea();
        note.setPadding(new Insets(0,10,0,10));
        note.setPrefSize(width*0.8, height*0.8);
        bp.setCenter(note);
        contactPanel = new ContactCreateUpdatePanel(this);
        createUpdateContact = contactPanel.getScene();
        createUpdateContact.getStylesheets().add("mainStyle.css");
        
        VBox leftSideBox = new VBox();
        leftSideBox.getStyleClass().add("screen");
        Button createContactBtn = new Button();
        createContactBtn.setText("Create Contact");
        createContactBtn.setFont(btnFont);
        createContactBtn.setPrefHeight(btnHeight);
        createContactBtn.setPrefWidth(btnWidth);
        createContactBtn.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                primaryStage.setScene(createUpdateContact);
            }
        });
        
        Button createReminderBtn = new Button();
        createReminderBtn.setText("Add as Reminder");
        createReminderBtn.setFont(btnFont);
        createReminderBtn.setPrefHeight(btnHeight);
        createReminderBtn.setPrefWidth(btnWidth);
        createReminderBtn.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                 if (note.getText().isEmpty()){
                    message.setText("Note is empty! Reminder can't be saved!");
                    return;
                }
                primaryStage.setScene(createReminder);
            }
        });
        
        Button createEventBtn = new Button();
        createEventBtn.setText("Add as Event");
        createEventBtn.setFont(btnFont);
        createEventBtn.setPrefHeight(btnHeight);
        createEventBtn.setPrefWidth(btnWidth);
        createEventBtn.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                 if (note.getText().isEmpty()){
                    message.setText("Note is empty! Event can't be saved!");
                    return;
                }
                primaryStage.setScene(createEvent);
            }
        });
        
        Button createNoteBtn = new Button();
        createNoteBtn.setText("Add as Note");
        createNoteBtn.setFont(btnFont);
        createNoteBtn.setPrefHeight(btnHeight);
        createNoteBtn.setPrefWidth(btnWidth);
        createNoteBtn.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                if (note.getText().isEmpty()){
                    message.setText("Note is empty! It can't be saved!");
                    return;
                }
                handler.addNote(handler.createNote(note.getText()));
                int length = 10;
                if (note.getText().length()<10){
                    length = note.getText().length();
                }
                
                message.setText("Note '" + note.getText(0, length-1) + "... is saved successfully!");
                note.setText("");
                
            }
        });
        
        leftSideBox.getChildren().addAll(createContactBtn, createReminderBtn, createEventBtn, createNoteBtn);
        bp.setLeft(leftSideBox);
        /**
         * Now we will set up the add as reminder form
         */
        
        GridPane gridPaneCR = new GridPane();
        gridPaneCR.getStylesheets().add("mainStyle.css");
        gridPaneCR.setAlignment(Pos.CENTER);
        gridPaneCR.setPadding(new Insets(40, 40, 40, 40));
        gridPaneCR.setHgap(10);
        gridPaneCR.setVgap(10);
        
        Button goBackCR = getBackButton();
        
        // Add the labels and the fields to the the gridPaneUR we created.
        Label headerLabelR = new Label("Add the following note as a reminder:\n\n" + note.getText());
        headerLabelR.setFont(Font.font("ArialBlack", 18));
        gridPaneCR.add(headerLabelR, 0,0,1,1);
        GridPane.setHalignment(headerLabelR, HPos.CENTER);
        GridPane.setMargin(headerLabelR, new Insets(10, 0,10,0));
        
        final DatePicker dp = new DatePicker();
        
        Label reminderDayLabel = new Label("Date : ");
        gridPaneCR.add(reminderDayLabel, 0, 5);
        TextField reminderDayField = new TextField();
        reminderDayField.setPrefHeight(20);
        gridPaneCR.add(dp, 1, 5);
        
        

        // Add Submit Button for reminder
        Button submitReminder = new Button("Submit");
        submitReminder.setPrefHeight(40);
        submitReminder.setDefaultButton(true);
        submitReminder.setPrefWidth(100);
        gridPaneCR.add(submitReminder, 0, 8, 2, 1);
        
        gridPaneCR.add(goBackCR, 0, 9, 2,1);
        GridPane.setHalignment(submitReminder, HPos.CENTER);
        GridPane.setMargin(submitReminder, new Insets(20, 0,20,0));
        submitReminder.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                System.out.println("Reminder edit opened.");
                int day = 0, month=0, year = 0;
                try{
                day = dp.getValue().getDayOfMonth();
                month = dp.getValue().getMonthValue();
                year = dp.getValue().getYear();
                } catch (Exception e){
                    //If date is invalid then
                    e.printStackTrace();
                    return;
                }
                handler.addReminder(handler.createReminder(note.getText(), day, month, year));
                note.setText("");
                primaryStage.setScene(mainScene);
            }
            });
        
        createReminder = new Scene(gridPaneCR, width, height);
        createReminder.getStylesheets().add("mainStyle.css");
        createEventPanel = new EventPanel(this);
        createEvent = createEventPanel.getScene();
        createEvent.getStylesheets().add("mainStyle.css");
        
        
        /**
         * Now we will create the scene for displaying the data stored in the app.
         */
        scroll_pane = new ScrollPane();
        scroll_pane.getStyleClass().add("screen");
        contactsBox.getStyleClass().add("screen");
        contactsBox.setPrefHeight(height);
        notesBox.getStyleClass().add("screen");
        notesBox.setPrefHeight(height);
        remindersBox.getStyleClass().add("screen");
        remindersBox.setPrefHeight(height);
        eventsBox.getStyleClass().add("screen");
        eventsBox.setPrefHeight(height);
        
        data_view = new Scene(scroll_pane, width, height);
        data_view.getStylesheets().add("mainStyle.css");
        
        /**
         * Now we will make the side panel of right side.
         */

        VBox rightSideBox = new VBox();
        rightSideBox.getStyleClass().add("screen");
        Button seeContacts = new Button();
        seeContacts.setText("View Contacts");
        seeContacts.setFont(btnFont);
        seeContacts.setPrefHeight(btnHeight);
        seeContacts.setPrefWidth(btnWidth);
        seeContacts.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                updateDataBox();
                scroll_pane.setContent(contactsBox);
                primaryStage.setScene(data_view);
            }
        });

        Button seeReminders = new Button();
        seeReminders.setText("See Reminders");
        seeReminders.setFont(btnFont);
        seeReminders.setPrefHeight(btnHeight);
        seeReminders.setPrefWidth(btnWidth);
        seeReminders.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                updateDataBox();
                scroll_pane.setStyle(mainStyle);
                 scroll_pane.setContent(remindersBox);
                primaryStage.setScene(data_view);
            }
        });
        

        Button seeEvents = new Button();
        seeEvents.setText("See Events");
        seeEvents.setFont(btnFont);
        seeEvents.setPrefHeight(btnHeight);
        seeEvents.setPrefWidth(btnWidth);
        seeEvents.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                updateDataBox();
                 scroll_pane.setContent(eventsBox);
                primaryStage.setScene(data_view);
            }
        });
        
        
        Button seeNote = new Button();
        seeNote.setText("See Notes");
        seeNote.setFont(btnFont);
        seeNote.setPrefHeight(btnHeight);
        seeNote.setPrefWidth(btnWidth);
        seeNote.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                updateDataBox();
                 scroll_pane.setContent(notesBox);
                primaryStage.setScene(data_view);
            }
        });
        
        Button exportHTML = new Button("Export as HTML");
        exportHTML.setFont(btnFont);
        exportHTML.setPrefHeight(btnHeight);
        exportHTML.setPrefWidth(btnWidth);

        exportHTML.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                FileChooser fileChooser = new FileChooser();

                //Set extension filter for text files
                FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("HTML files (*.html)", "*.htm","*.html");
                fileChooser.getExtensionFilters().add(extFilter);

                //Show save file dialog
                File file = fileChooser.showSaveDialog(primaryStage);

                if (file != null) {
                    handler.exportHTMLToFile(file);
                    message.setText("Data Exported Successfully! File Saved: " + file.toString());
                    return;
                }
                message.setText("Export Cancelled!");
                
                }
        });
        
        
        
        rightSideBox.getChildren().addAll(seeContacts, seeReminders, seeEvents, seeNote, exportHTML);
        
        bp.setRight(rightSideBox);
        
        mainScene = new Scene(bp, width, height);
        mainScene.getStylesheets().add("mainStyle.css");
    }

    public void stop() throws IOException{
        if (userAuthentication)
            handler.updateDatabase();
    }
    /**
     * Main method for our application.
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
    Button getBackButton(){
        return getBackButton(100,50);
    }
    Button getBackButton(double b_width, double b_height){
        Button goBack = new Button("Go Back!");
        goBack.setPrefHeight(b_height);
        goBack.setPrefWidth(b_width);
        GridPane.setHalignment(goBack, HPos.CENTER);
        GridPane.setMargin(goBack, new Insets(20, 0,20,0));
        goBack.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                primaryStage.setScene(mainScene);
            }
            });
        
        return goBack;
        
    }
    
    public void updateDataBox(){
    /**
     * Now we will create VBoxes for scenes to display contacts, events, and reminders.
     */
    
        Font heading = Font.font(STYLESHEET_CASPIAN, FontPosture.REGULAR, 25);

        contactsBox.getChildren().clear();
        contactsBox.getChildren().add(goBackCB);
        Label c_label = new Label("\nContacts");
        c_label.setFont(heading);
        c_label.setPrefWidth(width);
        c_label.setAlignment(Pos.CENTER);
        contactsBox.getChildren().add(c_label);

        for (Contact c: handler.contactsArray){

            GridPane cpane  = getContactPane(c);
            contactsBox.getChildren().add(cpane);
        }
        
        
        eventsBox.getChildren().clear();
        eventsBox.getChildren().add(goBackEB);
        Label e_label = new Label("\nEvents");
        e_label.setPrefWidth(width);
        e_label.setAlignment(Pos.CENTER);
        e_label.setFont(heading);
        eventsBox.getChildren().add(e_label);
        for (Event e: handler.eventsArray){
            GridPane epane = getEventPane(e);
            eventsBox.getChildren().add(epane);
        }
        remindersBox.getChildren().clear();
        remindersBox.getChildren().add(goBackRB);
        Label r_label = new Label("\nReminders");
        r_label.setPrefWidth(width);
        r_label.setAlignment(Pos.CENTER);
        r_label.setFont(heading);
        remindersBox.getChildren().add(r_label);
        for (Reminder r: handler.remindersArray){
            GridPane rpane = getReminderPane(r);
            remindersBox.getChildren().add(rpane);
        }
        
        //Notes Box
        notesBox.getChildren().clear();
        notesBox.getChildren().add(goBackNB);
        Label n_label = new Label("Notes");
        n_label.setPrefWidth(width);
        n_label.setAlignment(Pos.CENTER);
        n_label.setFont(heading);
        notesBox.getChildren().add(n_label);
        for (Note n:handler.notesArray){
            GridPane notePane = getNotePane(n);
            notesBox.getChildren().add(notePane);
        }
    
    }
    
    GridPane getNotePane(final Note n){
        GridPane notePane = new GridPane();
        notePane.setPrefWidth(width);
         notePane.setPrefHeight(200);
         notePane.setPadding(new Insets(10, 10, 10, 10));
         notePane.setHgap(5);
         notePane.setVgap(2);
         final Label message = new Label();
         message.setPadding(buttonInsets);
         message.setFont(Font.font(STYLESHEET_CASPIAN, FontWeight.BOLD, FontPosture.REGULAR, 15));
         message.setPrefWidth(width*0.8);
         Label date = new Label(n.getFormattedDate(n.getDateCreated()));
         date.setFont(Font.font(STYLESHEET_CASPIAN, FontWeight.BOLD, FontPosture.REGULAR, 15));
         final TextArea nta = new TextArea(n.getNote());
         nta.setPrefWidth(width*0.8);
         ScrollPane sp = new ScrollPane();
         sp.setPrefHeight(300);
         sp.setPrefWidth(width*0.8);
         sp.setContent(nta);
         
         notePane.add(date, 0, 0);
         notePane.add(sp,0, 1);
         
         notePane.getStyleClass().add("notePane");
         
         Button updateNote = new Button("Update");
         updateNote.setFont(Font.font(20));
         updateNote.setPrefHeight(btnHeight);
         updateNote.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                n.setNote(nta.getText());
                if (!handler.notesArray.contains(n)){
                    //note has been deleted!
                    handler.addNote(n);
                    message.setText("Note re-saved!");
                    return;
                    
                }
                n.setNote(nta.getText());
                message.setText("Note updated!");
            }
            }); 
         Button deleteNote = new Button("Delete");
         
         deleteNote.setFont(Font.font(20));
         deleteNote.setPrefHeight(btnHeight);
         
         final Alert a = new Alert(AlertType.NONE); 
        // action event 
        
       deleteNote.setOnAction( new 
                         EventHandler<ActionEvent>() { 
            public void handle(ActionEvent e) 
            { 
                a.setAlertType(AlertType.CONFIRMATION); 
                Optional<ButtonType> option = a.showAndWait();
                
                if (option.get().getText().equals("OK")) {
                   handler.deleteNote(n);
                   message.setText("Note deleted!");
                } 
            }
            }
        );
       
        notePane.add(updateNote, 1,1);
        notePane.add(deleteNote,2,1);
        notePane.add(message,0,2);
       
       
         return notePane;
    }
    
    GridPane getEventPane(final Event e){
        GridPane eventPane = new GridPane();
        eventPane.getStyleClass().add("eventPane");
        eventPane.setPrefWidth(width);
         eventPane.setPrefHeight(200);
         eventPane.setPadding(new Insets(10, 10, 10, 10));
         eventPane.setHgap(5);
         eventPane.setVgap(2);
         final Label message = new Label();
         message.setPadding(buttonInsets);
         message.setFont(Font.font(STYLESHEET_CASPIAN, FontWeight.BOLD, FontPosture.REGULAR, 16));
         message.setPrefWidth(width*0.8);
         
         String loc = e.getLocation();
         if (loc.isEmpty()){
             loc = "Not Specified";
         }
         Label date = new Label(e.getFormattedDate(e.getOccurenceDate()) + "\t@\tLocation: " + loc);
         date.setFont(Font.font(STYLESHEET_CASPIAN, FontWeight.BOLD, FontPosture.REGULAR, 15));
         final TextArea nta = new TextArea(e.getNote());
         nta.setPrefWidth(width*0.8);
         ScrollPane sp = new ScrollPane();
         sp.setPrefHeight(300);
         sp.setPrefWidth(width*0.8);
         sp.setContent(nta);
         
         eventPane.add(date, 0, 0);
         eventPane.add(sp,0, 1);
         
         Button updateEvent = new Button("Update");
         updateEvent.setFont(Font.font(20));
         updateEvent.setPrefHeight(btnHeight);
         updateEvent.setOnAction(new EventHandler<ActionEvent>() {
             public void handle(ActionEvent event) {
             e.setNote(nta.getText());
             if (!handler.eventsArray.contains(e)){
                 //note has been deleted!
                 handler.addEvent(e);
                 message.setText("Event re-saved!");
                 return;
                 
             }
             e.setNote(nta.getText());
             message.setText("Event updated!");
        }
        }
        ); 
         
         Button deleteEvent = new Button("Delete");
         
         deleteEvent.setFont(Font.font(20));
         deleteEvent.setPrefHeight(btnHeight);
         
		final Alert a = new Alert(AlertType.NONE); 
        // action event 
        
       deleteEvent.setOnAction( new 
                         EventHandler<ActionEvent>() { 
            public void handle(ActionEvent ev) 
            { 
                a.setAlertType(AlertType.CONFIRMATION); 
                Optional<ButtonType> option = a.showAndWait();
                
                if (option.get().getText().equals("OK")) {
                   handler.deleteEvent(e);
                   message.setText("Event deleted!");
                } 
            }
            }
        );
       
        eventPane.add(updateEvent, 1,1);
        eventPane.add(deleteEvent,2,1);
        eventPane.add(message,0,2);
       
       
         return eventPane;
    }
    
    GridPane getReminderPane(final Reminder r){
        GridPane reminderPane = new GridPane();
        reminderPane.setPrefWidth(width);
         reminderPane.setPrefHeight(200);
         reminderPane.setPadding(new Insets(10, 10, 10, 10));
         reminderPane.setHgap(5);
         reminderPane.setVgap(2);
         final Label message = new Label();
         message.setPadding(buttonInsets);
         message.setFont(Font.font(STYLESHEET_CASPIAN, FontWeight.BOLD, FontPosture.REGULAR, 15));
         message.setPrefWidth(width*0.8);
         Label date = new Label(r.getFormattedDate(r.getReminderDate()) + " [created at: " +
                 r.getFormattedDate(r.getDateCreated()) + "]");
         date.setFont(Font.font(STYLESHEET_CASPIAN, FontWeight.BOLD, FontPosture.REGULAR, 15));
         final TextArea nta = new TextArea(r.getNote());
         nta.setPrefWidth(width*0.8);
         ScrollPane sp = new ScrollPane();
         sp.setPrefHeight(300);
         sp.setPrefWidth(width*0.8);
         sp.setContent(nta);
         
         reminderPane.add(date, 0, 0);
         reminderPane.add(sp,0, 1);
         
         Button updateReminder = new Button("Update");
         updateReminder.setFont(Font.font(20));
         updateReminder.setPrefHeight(btnHeight);
         updateReminder.setOnAction(new EventHandler<ActionEvent>() {
             public void handle(ActionEvent event) {
             r.setNote(nta.getText());
             if (!handler.remindersArray.contains(r)){
                 //note has been deleted!
                 handler.addReminder(r);
                 message.setText("Reminder re-saved!");
                 return;
                 
             }
             message.setText("Reminder updated!");
             }
          }
        ); 
         
         Button deleteReminder = new Button("Delete");
         
         deleteReminder.setFont(Font.font(20));
         deleteReminder.setPrefHeight(btnHeight);
         
         final Alert a = new Alert(AlertType.NONE); 
        // action reminder 
        
       deleteReminder.setOnAction( new 
                         EventHandler<ActionEvent>() { 
            public void handle(ActionEvent ev) 
            { 
                a.setAlertType(AlertType.CONFIRMATION); 
                Optional<ButtonType> option = a.showAndWait();
                
                if (option.get().getText().equals("OK")) {
                   handler.deleteReminder(r);
                   message.setText("Reminder deleted!");
                } 
            }
            }
        );
       
        reminderPane.add(updateReminder, 1,1);
        reminderPane.add(deleteReminder,2,1);
        reminderPane.add(message,0,2);
       
       
         return reminderPane;
    }
    
    
    
    GridPane getContactPane(final Contact c){
         GridPane contactPane = new GridPane();
         contactPane.setPrefWidth(width);
         contactPane.setPrefHeight(200);
         contactPane.setPadding(new Insets(20, 20, 20, 20));
         contactPane.setHgap(10);
         contactPane.setVgap(10);
         Label name  = new Label(c.getFirstName() + " " + c.getLastName());
         name.setFont(Font.font(STYLESHEET_CASPIAN, FontWeight.BOLD, FontPosture.REGULAR, 20));
         Label email  = new Label("Email: " + c.getEmailAddress());
         email.setFont(Font.font(STYLESHEET_CASPIAN, FontWeight.LIGHT, FontPosture.REGULAR, 15));
         Label phone  = new Label("Phone: " + c.getPhoneNumber());
         phone.setFont(Font.font(STYLESHEET_CASPIAN, FontWeight.LIGHT, FontPosture.REGULAR, 15));
         
         contactPane.getStyleClass().add("contactPane");
         VBox info = new VBox();
         info.setPrefWidth(width*0.5);
         info.getChildren().add(name);
         info.getChildren().add(email);
         info.getChildren().add(phone);
         
         contactPane.add(info,0,0);
         
         Button editContact = new Button("Edit");
         editContact.setFont(Font.font(20));
         
         editContact.setPrefWidth(btnWidth);
         editContact.setPrefHeight(btnHeight);
         
         editContact.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                contactPanel.updateFields(c);
                primaryStage.setScene(createUpdateContact);
            }
            }); 
         Button deleteContact = new Button("Delete");
         
         deleteContact.setFont(btnFont);
         deleteContact.setPrefWidth(btnWidth);
         deleteContact.setPrefHeight(btnHeight);
         
         final Alert a = new Alert(AlertType.NONE); 
        // action event 
        
       deleteContact.setOnAction( new 
                         EventHandler<ActionEvent>() { 
            public void handle(ActionEvent e) 
            { 
                a.setAlertType(AlertType.CONFIRMATION); 
                final Optional<ButtonType> option = a.showAndWait();
                
                if (option.get().getText().equals("OK")) {
                   handler.deleteContact(c);
                   message.setText("Contact deleted!");
                   primaryStage.setScene(mainScene);
                } 
            }
            }
        );
       
       contactPane.add(editContact, 1,0);
       contactPane.add(deleteContact,2,0);
       return contactPane;
         
    }
    
}