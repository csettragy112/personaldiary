/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package personaldiary.gui;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import personaldiary.User;

/**
 *
 * @author hit
 */
public class UserRegistrationPanel {

    private final Scene userRegistration;
    
    UserRegistrationPanel(final PersonalDiaryFX parent){
        //User Registration Screen
        GridPane gridPaneUR = new GridPane();
        gridPaneUR.getStyleClass().add("screen");
        gridPaneUR.setStyle(parent.mainStyle);
        gridPaneUR.setAlignment(Pos.CENTER);
        gridPaneUR.setPadding(new Insets(40, 40, 40, 40));
        gridPaneUR.setHgap(10);
        gridPaneUR.setVgap(10);

        // Add the labels and the fields to the the gridPaneUR we created.
        Label headerLabel = new Label("Registration Form");
        headerLabel.setFont(Font.font("ArialBlack", 24));
        gridPaneUR.add(headerLabel, 0,0,1,1);
        GridPane.setHalignment(headerLabel, HPos.CENTER);
        GridPane.setMargin(headerLabel, new Insets(10, 0,10,0));

        // Add first First Name Label
        Label firstnameLabel = new Label("First Name : ");
        gridPaneUR.add(firstnameLabel, 0,1);

        // Add Name Text Field
        final TextField firstnameField = new TextField();
        firstnameField.setPrefHeight(40);
        gridPaneUR.add(firstnameField, 1,1);

        // Add last Name Label
        Label lastnameLabel = new Label("Last Name : ");
        gridPaneUR.add(lastnameLabel, 0,2);

        // Add Name Text Field
        final TextField lastnameField = new TextField();
        lastnameField.setPrefHeight(40);
        gridPaneUR.add(lastnameField, 1,2);
        
        // Add Email Label
        final Label emailLabel = new Label("Email ID : ");
        gridPaneUR.add(emailLabel, 0, 3);

        // Add Email Text Field
        final TextField emailField = new TextField();
        emailField.setPrefHeight(40);
        gridPaneUR.add(emailField, 1, 3);

        // Add Phone Number Label
        Label phoneNumberLabel = new Label("Phone Number : ");
        gridPaneUR.add(phoneNumberLabel, 0, 4);
        final TextField phoneNumberField = new TextField();
        phoneNumberField.setPrefHeight(40);
        gridPaneUR.add(phoneNumberField, 1, 4);
        
         
        Label bdayDayLabel = new Label("Birthday Day : ");
        gridPaneUR.add(bdayDayLabel, 0, 5);
        final DatePicker bdayDateField = new DatePicker();
        bdayDateField.setPrefHeight(20);
        gridPaneUR.add(bdayDateField, 1, 5);
        
        
        Label bloodGroupLabel = new Label("Blood Group : ");
        gridPaneUR.add(bloodGroupLabel, 0, 8);
        final TextField bloodGroupField = new TextField();
        bloodGroupField.setPrefHeight(40);
        gridPaneUR.add(bloodGroupField, 1, 8);
        
        Label passwordLabel = new Label("Password : ");
        gridPaneUR.add(passwordLabel, 0, 9);
        final PasswordField passwordField = new PasswordField();
        passwordField.setPrefHeight(40);
        gridPaneUR.add(passwordField, 1, 9);
        
        
        // Add Submit Button
        Button submitButton = new Button("Submit");
        submitButton.setPrefHeight(40);
        submitButton.setDefaultButton(true);
        submitButton.setPrefWidth(100);
        gridPaneUR.add(submitButton, 0, 10 , 2, 1);
        
        final Label message = new Label("Fill the form and submit!\nAll fields are compulsory.");
        gridPaneUR.add(message, 0, 12, 2,1);
        
        
        GridPane.setHalignment(submitButton, HPos.CENTER);
        GridPane.setMargin(submitButton, new Insets(20, 0,20,0));
        
        submitButton.setOnAction(new EventHandler<ActionEvent>() {
         public void handle(ActionEvent event) {
                try {
                String firstName = firstnameField.getText();
                if (firstName.isEmpty()){
                    System.out.println("Name Required");
                    message.setText("Name required!");
                    return;
                }
                
                String lastName = lastnameField.getText();
                String email = emailField.getText();
                String phoneNumber = phoneNumberField.getText();
                
                int day = bdayDateField.getValue().getDayOfMonth();
                int month = bdayDateField.getValue().getMonthValue();
                int year = bdayDateField.getValue().getYear();
                String bloodgroup = bloodGroupField.getText();
                String password = passwordField.getText();
   
                System.out.println("Password is :" + password);
                if (password.isEmpty()){
                    System.out.println("Password Required");
                    message.setText("Password required!");
                    return;
                }
                User mainUser = new User(firstName, lastName, password);
                mainUser.setBirthDay(day, month, year);
                mainUser.setBloodGroup(bloodgroup);
                mainUser.setEmailAddress(email);
                mainUser.setPhoneNumber(phoneNumber);
                parent.userAuthentication = true;
                parent.handler.updateUserInformation(mainUser); //Update the user.
                parent.createScenes();
                parent.primaryStage.setScene(parent.mainScene);
                
                } catch (Exception e) {
                    return;
                }
            }
        });
        
        userRegistration = new Scene(gridPaneUR, PersonalDiaryFX.width, PersonalDiaryFX.height);
    }
    
    Scene getScene(){
        return userRegistration;
    }
    
}
